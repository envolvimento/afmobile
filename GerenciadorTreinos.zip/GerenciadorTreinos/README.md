# Gerenciador de Treinos
Aplicativo Android básico para gerenciamento de treinos com Firebase.